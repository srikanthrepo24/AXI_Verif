
AXI Full Slave Model (Behavioral)
Files:
 - axi_full_slave.sv : behavioral AXI slave supporting many AXI features:
     - INCR/FIXED/WRAP bursts
     - Multiple outstanding IDs (interleaving)
     - Out-of-order completion (configurable)
     - Exclusive access reservation support (basic)
     - WSTRB handling, byte-addressable memory

Notes:
 - This model is behavioral and intended for verification; not fully synthesizable.
 - Exclusive access semantics are simplified: reservation granularity is per-starting-byte.
 - Reordering behavior is simplified; REORDER_ENABLED parameter controls whether multiple completed ops
   can be serviced out-of-order. For deterministic behavior set REORDER_ENABLED=0.
 - Tweak MEM_SIZE, MAX_OUTSTANDING for your use case.
 - Combine this DUT with the AXI UVM TB produced earlier by wiring signals in top module.
